package com.arenatournament.tournament;

import com.arenatournament.ArenaTournamentPlugin;
import com.arenatournament.arena.ArenaDefinition;
import com.arenatournament.model.MatchStatus;
import com.arenatournament.model.TournamentMatch;
import com.arenatournament.model.TournamentStatus;
import com.arenatournament.player.PlayerSnapshot;
import org.bukkit.Material;
import org.bukkit.GameMode;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.entity.Item;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

/** Registration, bracket progression, arena assignment and basic match lifecycle. */
public final class TournamentManager {
    private final ArenaTournamentPlugin plugin;
    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Set<UUID> byePlayers = new LinkedHashSet<>();
    private final List<TournamentMatch> matches = new ArrayList<>();
    private final Map<UUID, TournamentMatch> activeByPlayer = new HashMap<>();
    private final Map<UUID, BukkitTask> disconnectTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> countdownTasks = new HashMap<>();
    private final Map<UUID, BukkitTask> matchTimerTasks = new HashMap<>();
    private final Map<UUID, Integer> remainingMatchSeconds = new HashMap<>();
    private final Map<UUID, PlayerSnapshot> snapshots = new HashMap<>();
    private final Set<UUID> currentRoundWinners = new LinkedHashSet<>();
    private TournamentStatus status = TournamentStatus.IDLE;
    private int currentRound = 0;
    private UUID champion;

    public TournamentManager(ArenaTournamentPlugin plugin) {
        this.plugin = plugin;
        if (plugin.getConfig().getBoolean("tournament.registration-open-on-enable", false)) openRegistration();
    }

    public boolean openRegistration() {
        if (status != TournamentStatus.IDLE && status != TournamentStatus.CANCELLED) return false;
        clearRuntime(); participants.clear(); byePlayers.clear(); matches.clear();
        currentRound = 0; champion = null; status = TournamentStatus.REGISTRATION;
        return true;
    }

    public boolean register(UUID playerId) {
        if (status != TournamentStatus.REGISTRATION) return false;
        int cap = plugin.getConfig().getInt("tournament.max-players", 24);
        if (participants.size() >= cap || participants.contains(playerId)) return false;
        return participants.add(playerId);
    }

    public boolean unregister(UUID playerId) {
        return status == TournamentStatus.REGISTRATION && participants.remove(playerId);
    }

    public boolean start() {
        int cap = plugin.getConfig().getInt("tournament.max-players", 24);
        int byes = plugin.getConfig().getInt("tournament.first-round-byes", 8);
        if (status != TournamentStatus.REGISTRATION || participants.size() != cap || cap != 24 || byes != 8) return false;
        List<ArenaDefinition> arenas = plugin.getWorldBuilder().getArenas();
        if (arenas.size() < 8) {
            plugin.getLogger().warning("Cannot start: eight generated arenas are required.");
            return false;
        }
        List<UUID> pool = new ArrayList<>(participants);
        Collections.shuffle(pool);
        byePlayers.addAll(pool.subList(0, byes));
        List<UUID> roundOnePlayers = pool.subList(byes, pool.size());
        for (int i = 0; i < roundOnePlayers.size(); i += 2)
            matches.add(new TournamentMatch(1, roundOnePlayers.get(i), roundOnePlayers.get(i + 1)));
        currentRound = 1;
        status = TournamentStatus.RUNNING;
        announce("Tournament started! Round 1 matches are being assigned.");
        launchWaitingMatches();
        return true;
    }

    private void launchWaitingMatches() {
        if (status != TournamentStatus.RUNNING) return;
        List<ArenaDefinition> arenas = plugin.getWorldBuilder().getArenas();
        Set<String> occupied = new HashSet<>();
        for (TournamentMatch m : matches) if (m.getStatus() != MatchStatus.FINISHED && m.getArenaId() != null) occupied.add(m.getArenaId());
        int launched = 0;
        int maxSimultaneous = Math.max(1, plugin.getConfig().getInt("matches.simultaneous-matches", 8));
        long alreadyActive = matches.stream().filter(m -> m.getRound() == currentRound
                && (m.getStatus() == MatchStatus.COUNTDOWN || m.getStatus() == MatchStatus.RUNNING)).count();
        for (TournamentMatch match : matches) {
            if (alreadyActive + launched >= maxSimultaneous) break;
            if (match.getRound() != currentRound || match.getStatus() != MatchStatus.WAITING) continue;
            ArenaDefinition arena = arenas.stream().filter(a -> !occupied.contains(a.id())).findFirst().orElse(null);
            if (arena == null) break;
            Player p1 = Bukkit.getPlayer(match.getPlayerOne());
            Player p2 = Bukkit.getPlayer(match.getPlayerTwo());
            if (p1 == null || p2 == null) {
                if (p1 == null && p2 == null) { finishMatch(match, null, "Both players were offline at launch; match held for admin review."); }
                else finishMatch(match, p1 != null ? p1.getUniqueId() : p2.getUniqueId(), "Opponent unavailable at match launch.");
                continue;
            }
            clearArenaItems(arena);
            match.setArenaId(arena.id());
            match.setStatus(MatchStatus.COUNTDOWN);
            occupied.add(arena.id());
            activeByPlayer.put(p1.getUniqueId(), match);
            activeByPlayer.put(p2.getUniqueId(), match);
            try {
                captureAndPrepare(p1);
                captureAndPrepare(p2);
            } catch (java.io.IOException ex) {
                plugin.getLogger().severe("Could not safely back up match inventories: " + ex.getMessage());
                restorePlayer(p1.getUniqueId());
                restorePlayer(p2.getUniqueId());
                activeByPlayer.remove(p1.getUniqueId()); activeByPlayer.remove(p2.getUniqueId());
                occupied.remove(arena.id());
                match.setArenaId(null); match.setStatus(MatchStatus.WAITING);
                continue;
            }
            p1.teleport(arena.playerOneSpawn()); p2.teleport(arena.playerTwoSpawn());
            int seconds = Math.max(1, plugin.getConfig().getInt("matches.countdown-seconds", 10));
            BukkitRunnable countdown = new BukkitRunnable() {
                int remaining = seconds;
                @Override public void run() {
                    if (match.getStatus() != MatchStatus.COUNTDOWN) {
                        countdownTasks.remove(match.getId());
                        cancel();
                        return;
                    }
                    if (status == TournamentStatus.PAUSED) return;
                    Player a = Bukkit.getPlayer(match.getPlayerOne());
                    Player b = Bukkit.getPlayer(match.getPlayerTwo());
                    if (a == null || b == null) {
                        // Keep the countdown frozen while the configured reconnect grace period runs.
                        return;
                    }
                    if (remaining <= 0) {
                        match.setStatus(MatchStatus.RUNNING);
                        startMatchTimer(match);
                        a.sendTitle("FIGHT!", "", 0, 25, 5); b.sendTitle("FIGHT!", "", 0, 25, 5);
                        a.sendMessage("Your match has started against " + b.getName() + ".");
                        b.sendMessage("Your match has started against " + a.getName() + ".");
                        countdownTasks.remove(match.getId());
                        cancel();
                        return;
                    }
                    a.sendTitle("" + remaining, "Get ready", 0, 20, 0);
                    b.sendTitle("" + remaining, "Get ready", 0, 20, 0);
                    remaining--;
                }
            };
            countdownTasks.put(match.getId(), countdown.runTaskTimer(plugin, 0L, 20L));
            launched++;
        }
        if (launched > 0) plugin.getLogger().info("Launched " + launched + " match(es) in round " + currentRound + ".");
    }

    public void handleDeath(Player defeated) {
        TournamentMatch match = activeByPlayer.get(defeated.getUniqueId());
        if (match == null || match.getStatus() == MatchStatus.FINISHED) return;
        UUID winner = match.opponentOf(defeated.getUniqueId());
        finishMatch(match, winner, defeated.getName() + " was eliminated.");
    }

    public void handleQuit(Player player) {
        TournamentMatch match = activeByPlayer.get(player.getUniqueId());
        if (match == null || match.getStatus() == MatchStatus.FINISHED) return;
        int grace = Math.max(0, plugin.getConfig().getInt("matches.disconnect-grace-seconds", 30));
        BukkitTask old = disconnectTasks.remove(player.getUniqueId()); if (old != null) old.cancel();
        BukkitTask task = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            TournamentMatch current = activeByPlayer.get(player.getUniqueId());
            if (current == match && current.getStatus() != MatchStatus.FINISHED) {
                UUID opponentId = current.opponentOf(player.getUniqueId());
                UUID winner = opponentId != null && Bukkit.getPlayer(opponentId) != null ? opponentId : null;
                finishMatch(current, winner, player.getName() + " did not reconnect before the grace period ended.");
            }
            disconnectTasks.remove(player.getUniqueId());
        }, grace * 20L);
        disconnectTasks.put(player.getUniqueId(), task);
    }

    public void handleJoin(Player player) {
        BukkitTask task = disconnectTasks.remove(player.getUniqueId());
        if (task != null) task.cancel();
        TournamentMatch match = activeByPlayer.get(player.getUniqueId());
        if (match != null && match.getStatus() != MatchStatus.FINISHED) {
            ArenaDefinition arena = arenaFor(match.getArenaId());
            if (arena != null) player.teleport(match.getPlayerOne().equals(player.getUniqueId()) ? arena.playerOneSpawn() : arena.playerTwoSpawn());
            player.sendMessage("You rejoined your active tournament match.");
        } else {
            restorePlayer(player.getUniqueId());
        }
    }

    private void finishMatch(TournamentMatch match, UUID winner, String reason) {
        if (match.getStatus() == MatchStatus.FINISHED) return;
        cancelCountdown(match);
        cancelMatchTimer(match);
        ArenaDefinition finishedArena = arenaFor(match.getArenaId());
        if (finishedArena != null) clearArenaItems(finishedArena);
        if (winner == null) {
            match.setStatus(MatchStatus.FINISHED);
            plugin.getLogger().warning("Match " + match.getId() + " ended without a winner: " + reason);
        } else {
            match.finish(winner);
            currentRoundWinners.add(winner);
            announce(name(winner) + " won a round " + match.getRound() + " match. " + reason);
        }
        activeByPlayer.remove(match.getPlayerOne()); activeByPlayer.remove(match.getPlayerTwo());
        cancelDisconnect(match.getPlayerOne()); cancelDisconnect(match.getPlayerTwo());
        restorePlayer(match.getPlayerOne()); restorePlayer(match.getPlayerTwo());
        sendToLobby(match.getPlayerOne()); sendToLobby(match.getPlayerTwo());
        if (matches.stream().filter(m -> m.getRound() == currentRound).allMatch(m -> m.getStatus() == MatchStatus.FINISHED)) advanceRound();
        else launchWaitingMatches();
    }

    private void startMatchTimer(TournamentMatch match) {
        int duration = Math.max(30, plugin.getConfig().getInt("matches.duration-seconds", 900));
        remainingMatchSeconds.put(match.getId(), duration);
        BukkitTask task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (match.getStatus() != MatchStatus.RUNNING) {
                cancelMatchTimer(match);
                return;
            }
            if (status == TournamentStatus.PAUSED) return;
            Player one = Bukkit.getPlayer(match.getPlayerOne());
            Player two = Bukkit.getPlayer(match.getPlayerTwo());
            // A disconnected fighter's grace period should not consume the match clock.
            if (one == null || two == null) return;
            int remaining = remainingMatchSeconds.getOrDefault(match.getId(), duration) - 1;
            remainingMatchSeconds.put(match.getId(), remaining);
            if (remaining == 60 || remaining == 30 || remaining == 10 || remaining <= 5) {
                String message = "Match time remaining: " + remaining + "s";
                one.sendMessage("§e" + message);
                two.sendMessage("§e" + message);
            }
            if (remaining <= 0) resolveTimeout(match, one, two);
        }, 20L, 20L);
        matchTimerTasks.put(match.getId(), task);
    }

    private void resolveTimeout(TournamentMatch match, Player one, Player two) {
        double oneScore = effectiveHealth(one);
        double twoScore = effectiveHealth(two);
        double difference = Math.abs(oneScore - twoScore);
        if (difference < 0.0001) {
            one.sendMessage("§cTime limit reached: the match is tied. Admin review is required.");
            two.sendMessage("§cTime limit reached: the match is tied. Admin review is required.");
            announce("A match ended in a timeout tie. The tournament is paused for admin review.");
            status = TournamentStatus.PAUSED;
            finishMatch(match, null, "Time limit reached with equal remaining health.");
            return;
        }
        UUID winner = oneScore > twoScore ? one.getUniqueId() : two.getUniqueId();
        Player winnerPlayer = oneScore > twoScore ? one : two;
        Player loserPlayer = oneScore > twoScore ? two : one;
        winnerPlayer.sendMessage("§aYou won on remaining health when the match time expired.");
        loserPlayer.sendMessage("§cYou lost on remaining health when the match time expired.");
        finishMatch(match, winner, "Time limit reached; higher remaining health won.");
    }

    private double effectiveHealth(Player player) {
        double max = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) == null
                ? 20.0 : player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
        return Math.min(1.0, (player.getHealth() + player.getAbsorptionAmount()) / Math.max(1.0, max));
    }

    private void cancelMatchTimer(TournamentMatch match) {
        BukkitTask task = matchTimerTasks.remove(match.getId());
        if (task != null) task.cancel();
        remainingMatchSeconds.remove(match.getId());
    }

    private void clearArenaItems(ArenaDefinition arena) {
        if (!plugin.getConfig().getBoolean("matches.cleanup-dropped-items", true)) return;
        for (org.bukkit.entity.Entity entity : arena.world().getNearbyEntities(
                new org.bukkit.util.BoundingBox(arena.minX(), arena.minY(), arena.minZ(),
                        arena.maxX() + 1.0, arena.maxY() + 1.0, arena.maxZ() + 1.0))) {
            if (entity instanceof Item) entity.remove();
        }
    }

    private void advanceRound() {
        List<UUID> advancing = new ArrayList<>();
        if (currentRound == 1) advancing.addAll(byePlayers);
        advancing.addAll(currentRoundWinners);
        currentRoundWinners.clear();
        if (advancing.size() == 1) {
            champion = advancing.get(0); status = TournamentStatus.COMPLETED;
            announce("Tournament champion: " + name(champion) + "!"); return;
        }
        if (advancing.size() < 2 || advancing.size() % 2 != 0) {
            status = TournamentStatus.PAUSED;
            plugin.getLogger().severe("Bracket progression stopped: " + advancing.size() + " players advanced. Admin review required.");
            return;
        }
        currentRound++;
        Collections.shuffle(advancing);
        for (int i = 0; i < advancing.size(); i += 2) matches.add(new TournamentMatch(currentRound, advancing.get(i), advancing.get(i + 1)));
        announce("Round " + currentRound + " is ready. " + (advancing.size() / 2) + " matches.");
        launchWaitingMatches();
    }

    private ArenaDefinition arenaFor(String id) {
        if (id == null) return null;
        return plugin.getWorldBuilder().getArenas().stream().filter(a -> a.id().equals(id)).findFirst().orElse(null);
    }
    private void sendToLobby(UUID id) {
        Player p = Bukkit.getPlayer(id); if (p == null || p.isDead()) return;
        Location lobby = configuredLocation("world.lobby"); if (lobby != null) p.teleport(lobby);
    }
    private Location configuredLocation(String path) {
        String worldName = plugin.getConfig().getString(path + ".world", plugin.getConfig().getString("world.tournament-world", "TournamentWorld"));
        org.bukkit.World world = Bukkit.getWorld(worldName); if (world == null) return null;
        return new Location(world, plugin.getConfig().getDouble(path + ".x"), plugin.getConfig().getDouble(path + ".y"), plugin.getConfig().getDouble(path + ".z"));
    }
    private void captureAndPrepare(Player player) throws java.io.IOException {
        UUID id = player.getUniqueId();
        if (plugin.getViewManager() != null && plugin.getViewManager().isSpectator(id)) plugin.getViewManager().stopSpectating(player);
        player.closeInventory();
        if (!snapshots.containsKey(id)) snapshots.put(id, PlayerSnapshot.captureAndSave(plugin, player));
        player.getInventory().clear();
        player.getInventory().setArmorContents(new ItemStack[4]);
        player.getInventory().setItemInOffHand(null);
        for (PotionEffect effect : player.getActivePotionEffects()) player.removePotionEffect(effect.getType());
        player.setGameMode(GameMode.SURVIVAL);
        player.setAllowFlight(false);
        player.setFlying(false);
        player.setFireTicks(0);
        double maxHealth = player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH) == null
                ? 20 : player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue();
        player.setHealth(Math.min(20, maxHealth));
        player.setFoodLevel(20);
        player.setSaturation(20);
        player.setLevel(0);
        player.setExp(0);
        player.setTotalExperience(0);
        if (plugin.getConfig().getBoolean("kit.enabled", true)) {
            for (String entry : plugin.getConfig().getStringList("kit.items")) {
                String[] parts = entry.split(":", 2);
                Material material = Material.matchMaterial(parts[0].trim());
                if (material == null || !material.isItem()) {
                    plugin.getLogger().warning("Ignoring invalid kit item: " + entry);
                    continue;
                }
                int amount = 1;
                if (parts.length == 2) try { amount = Math.max(1, Math.min(64, Integer.parseInt(parts[1]))); }
                catch (NumberFormatException ignored) { }
                player.getInventory().addItem(new ItemStack(material, amount));
            }
            List<String> armor = plugin.getConfig().getStringList("kit.armor");
            ItemStack[] armorContents = new ItemStack[4];
            for (int i = 0; i < Math.min(4, armor.size()); i++) {
                Material material = Material.matchMaterial(armor.get(i));
                if (material != null && material.isItem()) armorContents[i] = new ItemStack(material);
            }
            player.getInventory().setArmorContents(armorContents);
        }
        player.updateInventory();
    }

    private void restorePlayer(UUID id) {
        Player player = Bukkit.getPlayer(id);
        if (player == null || player.isDead()) return;
        PlayerSnapshot snapshot = snapshots.remove(id);
        if (snapshot == null) snapshot = PlayerSnapshot.existing(plugin, id);
        if (snapshot != null) {
            try { snapshot.restore(player); }
            catch (java.io.IOException ex) { plugin.getLogger().severe("Could not restore inventory for " + id + ": " + ex.getMessage()); }
        }
    }
    private void cancelDisconnect(UUID id) { BukkitTask task = disconnectTasks.remove(id); if (task != null) task.cancel(); }
    private void cancelCountdown(TournamentMatch match) {
        BukkitTask task = countdownTasks.remove(match.getId());
        if (task != null) task.cancel();
    }
    private void clearRuntime() {
        disconnectTasks.values().forEach(BukkitTask::cancel); disconnectTasks.clear();
        countdownTasks.values().forEach(BukkitTask::cancel); countdownTasks.clear();
        matchTimerTasks.values().forEach(BukkitTask::cancel); matchTimerTasks.clear();
        remainingMatchSeconds.clear();
        activeByPlayer.clear();
        for (UUID id : new ArrayList<>(snapshots.keySet())) restorePlayer(id);
        currentRoundWinners.clear();
    }
    private void announce(String message) { Bukkit.broadcastMessage("§6[ArenaTournament] §f" + message); }
    private String name(UUID id) { OfflinePlayer p = Bukkit.getOfflinePlayer(id); return p.getName() == null ? id.toString().substring(0, 8) : p.getName(); }

    public boolean pause() { if (status != TournamentStatus.RUNNING) return false; status = TournamentStatus.PAUSED; announce("Tournament paused. Active matches are temporarily protected from player damage."); return true; }
    public boolean resume() { if (status != TournamentStatus.PAUSED) return false; status = TournamentStatus.RUNNING; announce("Tournament resumed."); launchWaitingMatches(); return true; }
    public void cancel() {
        for (TournamentMatch match : matches) {
            if (match.getStatus() != MatchStatus.FINISHED) {
                activeByPlayer.remove(match.getPlayerOne()); activeByPlayer.remove(match.getPlayerTwo());
                sendToLobby(match.getPlayerOne()); sendToLobby(match.getPlayerTwo());
                restorePlayer(match.getPlayerOne()); restorePlayer(match.getPlayerTwo());
            }
        }
        clearRuntime(); status = TournamentStatus.CANCELLED; matches.clear(); byePlayers.clear(); participants.clear(); currentRound = 0; champion = null;
    }
    public String getStatusLine() {
        long finished = matches.stream().filter(m -> m.getStatus() == MatchStatus.FINISHED).count();
        return "Status: " + status + " | Registered: " + participants.size() + "/" + plugin.getConfig().getInt("tournament.max-players", 24)
                + " | Round: " + (currentRound == 0 ? "Not started" : currentRound) + " | Matches: " + finished + "/" + matches.size()
                + (champion == null ? "" : " | Champion: " + name(champion));
    }
    public List<String> getBracketLines() {
        List<String> lines = new ArrayList<>();
        for (int round = 1; round <= currentRound; round++) {
            lines.add("Round " + round + ":"); int number = 1;
            for (TournamentMatch m : matches) if (m.getRound() == round)
                lines.add("  Match " + number++ + ": " + name(m.getPlayerOne()) + " vs " + name(m.getPlayerTwo()) + " [" + m.getStatus() + "]" + (m.getArenaId() == null ? "" : " @ " + m.getArenaId()) + (m.getWinner() == null ? "" : " Winner: " + name(m.getWinner())));
        }
        if (!byePlayers.isEmpty()) { lines.add("Round 1 byes:"); for (UUID id : byePlayers) lines.add("  BYE: " + name(id)); }
        if (lines.isEmpty()) lines.add("No tournament bracket has been generated yet.");
        return lines;
    }
    public TournamentStatus getStatus() { return status; }
    public boolean isPaused() { return status == TournamentStatus.PAUSED; }
    public boolean isActiveMatchPlayer(UUID playerId) { return activeByPlayer.containsKey(playerId); }
    public boolean isTournamentPlayer(UUID playerId) { return participants.contains(playerId); }
    public void handleRespawn(Player player) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!activeByPlayer.containsKey(player.getUniqueId())) restorePlayer(player.getUniqueId());
        });
    }
    public boolean canFight(UUID attacker, UUID victim) {
        TournamentMatch a = activeByPlayer.get(attacker);
        TournamentMatch v = activeByPlayer.get(victim);
        return status == TournamentStatus.RUNNING && a != null && a == v && a.getStatus() == MatchStatus.RUNNING;
    }
    public boolean isMatchRunning(UUID playerId) {
        TournamentMatch match = activeByPlayer.get(playerId);
        return status == TournamentStatus.RUNNING && match != null && match.getStatus() == MatchStatus.RUNNING;
    }
    public ArenaDefinition getArenaForPlayer(UUID playerId) {
        TournamentMatch match = activeByPlayer.get(playerId);
        return match == null ? null : arenaFor(match.getArenaId());
    }
    public Location getSpawnForPlayer(UUID playerId) {
        TournamentMatch match = activeByPlayer.get(playerId);
        ArenaDefinition arena = match == null ? null : arenaFor(match.getArenaId());
        if (arena == null) return null;
        return match.getPlayerOne().equals(playerId) ? arena.playerOneSpawn() : arena.playerTwoSpawn();
    }
    public int getParticipantCount() { return participants.size(); }
    public List<TournamentMatch> getMatches() { return List.copyOf(matches); }
    public List<TournamentMatch> getActiveMatches() {
        return matches.stream().filter(m -> m.getStatus() == MatchStatus.COUNTDOWN || m.getStatus() == MatchStatus.RUNNING).toList();
    }
    public TournamentMatch getMatch(UUID matchId) {
        return matches.stream().filter(m -> m.getId().equals(matchId)).findFirst().orElse(null);
    }
    public String getDisplayName(UUID id) { return name(id); }
    public int getCurrentRound() { return currentRound; }
    public UUID getChampion() { return champion; }
    public int getRemainingSeconds(UUID matchId) { return remainingMatchSeconds.getOrDefault(matchId, 0); }
    public int getWaitingMatchCount() {
        return (int) matches.stream().filter(m -> m.getRound() == currentRound && m.getStatus() == MatchStatus.WAITING).count();
    }
    public void shutdown() { clearRuntime(); plugin.getLogger().info("ArenaTournament stopped. Active bracket persistence/recovery is not included yet."); }
}
