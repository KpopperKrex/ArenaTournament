package com.arenatournament.model;

public enum TournamentStatus {
    IDLE,
    REGISTRATION,
    READY,
    RUNNING,
    PAUSED,
    COMPLETED,
    CANCELLED
}
