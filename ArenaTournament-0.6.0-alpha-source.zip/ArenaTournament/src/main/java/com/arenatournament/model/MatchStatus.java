package com.arenatournament.model;

public enum MatchStatus {
    WAITING,
    COUNTDOWN,
    RUNNING,
    FINISHED,
    RESETTING
}
