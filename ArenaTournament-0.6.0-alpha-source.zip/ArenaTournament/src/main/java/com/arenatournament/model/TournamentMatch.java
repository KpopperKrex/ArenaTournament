package com.arenatournament.model;

import java.util.UUID;

public final class TournamentMatch {
    private final UUID id;
    private final int round;
    private final UUID playerOne;
    private final UUID playerTwo;
    private MatchStatus status;
    private UUID winner;
    private String arenaId;

    public TournamentMatch(int round, UUID playerOne, UUID playerTwo) {
        this.id = UUID.randomUUID();
        this.round = round;
        this.playerOne = playerOne;
        this.playerTwo = playerTwo;
        this.status = MatchStatus.WAITING;
    }

    public UUID getId() { return id; }
    public int getRound() { return round; }
    public UUID getPlayerOne() { return playerOne; }
    public UUID getPlayerTwo() { return playerTwo; }
    public MatchStatus getStatus() { return status; }
    public UUID getWinner() { return winner; }
    public String getArenaId() { return arenaId; }
    public void setArenaId(String arenaId) { this.arenaId = arenaId; }
    public void setStatus(MatchStatus status) { this.status = status; }

    public boolean contains(UUID playerId) {
        return playerOne.equals(playerId) || playerTwo.equals(playerId);
    }

    public UUID opponentOf(UUID playerId) {
        if (playerOne.equals(playerId)) return playerTwo;
        if (playerTwo.equals(playerId)) return playerOne;
        return null;
    }

    public void finish(UUID winner) {
        if (status == MatchStatus.FINISHED) throw new IllegalStateException("Match has already been finalized");
        if (!contains(winner)) throw new IllegalArgumentException("Winner must be one of the match participants");
        this.winner = winner;
        this.status = MatchStatus.FINISHED;
    }
}
