package com.arenatournament.command;

import com.arenatournament.ArenaTournamentPlugin;
import com.arenatournament.arena.ArenaDefinition;
import com.arenatournament.tournament.TournamentManager;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class TournamentCommand implements CommandExecutor, TabCompleter {
    private final ArenaTournamentPlugin plugin;
    private final TournamentManager manager;

    public TournamentCommand(ArenaTournamentPlugin plugin, TournamentManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            help(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "join" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Only players can register themselves."); return true; }
                boolean ok = manager.register(player.getUniqueId());
                player.sendMessage(color(ok ? "&aYou are registered for the tournament." : "&cRegistration is closed, full, or you are already registered."));
            }
            case "leave" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Only players can unregister themselves."); return true; }
                player.sendMessage(color(manager.unregister(player.getUniqueId()) ? "&eYou left the tournament registration." : "&cYou cannot leave now."));
            }
            case "register" -> admin(sender, () -> {
                sender.sendMessage(color(manager.openRegistration() ? "&aRegistration opened." : "&cCannot open registration in the current state."));
            });
            case "start" -> admin(sender, () -> sender.sendMessage(color(manager.start()
                    ? "&aTournament started. Matches are being assigned to arenas."
                    : "&cStart failed. Registration must contain exactly 24 players.")));
            case "pause" -> admin(sender, () -> sender.sendMessage(color(manager.pause() ? "&eTournament paused." : "&cTournament cannot be paused now.")));
            case "resume" -> admin(sender, () -> sender.sendMessage(color(manager.resume() ? "&aTournament resumed." : "&cTournament is not paused.")));
            case "cancel" -> admin(sender, () -> { manager.cancel(); sender.sendMessage(color("&cTournament cancelled and registration data cleared.")); });
            case "setup" -> admin(sender, () -> {
                boolean ok = plugin.getWorldBuilder().setupIfNeeded();
                sender.sendMessage(color(ok ? "&aTournament world is loaded and arena locations are registered." : "&cCould not create or load the tournament world."));
            });
            case "arenas" -> {
                for (ArenaDefinition arena : plugin.getWorldBuilder().getArenas()) {
                    sender.sendMessage(color("&e" + arena.id() + " &7- &f" + arena.displayName() + " &7[" + arena.world().getName() + "]"));
                }
                if (plugin.getWorldBuilder().getArenas().isEmpty()) sender.sendMessage(color("&cNo arenas loaded. Ask an admin to run /at setup."));
            }
            case "validate" -> {
                int count = plugin.getWorldBuilder().getArenas().size();
                sender.sendMessage(color("&6[ArenaTournament] &fLoaded arenas: &e" + count + "/8"));
                sender.sendMessage(color(count == 8 ? "&aEight arenas are registered. Run /at start when all 24 players are registered." : "&cArena registry incomplete. Run /at setup."));
            }
            case "status" -> sender.sendMessage(color("&6[ArenaTournament] &f" + manager.getStatusLine()));
            case "bracket" -> {
                if (sender instanceof Player player) plugin.getViewManager().openBracketMenu(player);
                else manager.getBracketLines().forEach(line -> sender.sendMessage(color("&7" + line)));
            }
            case "spectate" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Only players can spectate."); return true; }
                sender.sendMessage(color(plugin.getViewManager().startSpectating(player) ? "&aSpectator mode enabled." : "&cSpectating is disabled in the config."));
            }
            case "watch" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Only players can watch matches."); return true; }
                plugin.getViewManager().openWatchMenu(player);
            }
            case "unspectate" -> {
                if (!(sender instanceof Player player)) { sender.sendMessage("Only players can leave spectator mode."); return true; }
                if (plugin.getViewManager().isSpectator(player.getUniqueId())) plugin.getViewManager().stopSpectating(player);
                else player.sendMessage(color("&cYou are not currently spectating."));
            }
            default -> sender.sendMessage(color("&cUnknown command. Use /at help."));
        }
        return true;
    }

    private void admin(CommandSender sender, Runnable action) {
        if (!sender.hasPermission("arenatournament.admin")) {
            sender.sendMessage(color("&cYou do not have permission to do that."));
            return;
        }
        action.run();
    }

    private void help(CommandSender sender) {
        sender.sendMessage(color("&6&lArenaTournament &7- alpha build"));
        sender.sendMessage(color("&e/at join &7- Register for the tournament"));
        sender.sendMessage(color("&e/at leave &7- Leave before registration closes"));
        sender.sendMessage(color("&e/at status &7- View tournament status"));
        sender.sendMessage(color("&e/at bracket &7- Open the tournament bracket"));
        sender.sendMessage(color("&e/at spectate &7- Enter spectator mode"));
        sender.sendMessage(color("&e/at watch &7- Choose a live match to watch"));
        sender.sendMessage(color("&e/at unspectate &7- Leave spectator mode"));
        sender.sendMessage(color("&cAdmin: /at setup, arenas, validate, register, start, pause, resume, cancel"));
    }

    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text); }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = List.of("help", "join", "leave", "status", "bracket", "spectate", "watch", "unspectate", "register", "start", "pause", "resume", "cancel", "setup", "arenas", "validate");
        if (args.length != 1) return List.of();
        String prefix = args[0].toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<>();
        for (String option : options) if (option.startsWith(prefix)) matches.add(option);
        return matches;
    }
}
