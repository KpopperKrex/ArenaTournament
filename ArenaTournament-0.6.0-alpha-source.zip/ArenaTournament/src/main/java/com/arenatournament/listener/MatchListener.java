package com.arenatournament.listener;

import com.arenatournament.arena.ArenaDefinition;
import com.arenatournament.tournament.TournamentManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class MatchListener implements Listener {
    private final JavaPlugin plugin;
    private final TournamentManager manager;

    public MatchListener(JavaPlugin plugin, TournamentManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onMatchDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (manager.isPaused() && manager.isActiveMatchPlayer(victim.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            Player attacker = playerDamager(byEntity);
            if (attacker != null && (manager.isActiveMatchPlayer(attacker.getUniqueId()) || manager.isActiveMatchPlayer(victim.getUniqueId()))) {
                if (!manager.canFight(attacker.getUniqueId(), victim.getUniqueId())) event.setCancelled(true);
            } else if (attacker == null && manager.isActiveMatchPlayer(victim.getUniqueId())
                    && !manager.isMatchRunning(victim.getUniqueId())) {
                event.setCancelled(true);
            }
        } else if (manager.isActiveMatchPlayer(victim.getUniqueId()) && !manager.isMatchRunning(victim.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    private Player playerDamager(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) return player;
        if (event.getDamager() instanceof Projectile projectile && projectile.getShooter() instanceof Player player) return player;
        return null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onArenaMovement(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        ArenaDefinition arena = manager.getArenaForPlayer(event.getPlayer().getUniqueId());
        if (arena == null || arena.contains(event.getTo())) return;
        Location safe = manager.getSpawnForPlayer(event.getPlayer().getUniqueId());
        if (safe != null) {
            event.getPlayer().teleport(safe);
            event.getPlayer().sendMessage("§cStay inside your assigned arena.");
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentBlockBreak(BlockBreakEvent event) {
        if (isTournamentWorld(event.getBlock().getWorld()) && !event.getPlayer().hasPermission("arenatournament.build")) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentBlockPlace(BlockPlaceEvent event) {
        if (isTournamentWorld(event.getBlock().getWorld()) && !event.getPlayer().hasPermission("arenatournament.build")) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentBlockBurn(BlockBurnEvent event) {
        if (isTournamentWorld(event.getBlock().getWorld())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentBlockIgnite(BlockIgniteEvent event) {
        if (isTournamentWorld(event.getBlock().getWorld())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentBlockExplosion(BlockExplodeEvent event) {
        if (isTournamentWorld(event.getBlock().getWorld())) event.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onTournamentEntityExplosion(EntityExplodeEvent event) {
        if (isTournamentWorld(event.getLocation().getWorld())) event.blockList().clear();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && manager.isActiveMatchPlayer(player.getUniqueId())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player && manager.isActiveMatchPlayer(player.getUniqueId())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (manager.isActiveMatchPlayer(event.getPlayer().getUniqueId())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player && manager.isActiveMatchPlayer(player.getUniqueId())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent event) {
        if (manager.isActiveMatchPlayer(event.getEntity().getUniqueId())) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            manager.handleDeath(event.getEntity());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) { manager.handleQuit(event.getPlayer()); }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) { manager.handleJoin(event.getPlayer()); }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        if (!manager.isTournamentPlayer(event.getPlayer().getUniqueId())) return;
        String worldName = plugin.getConfig().getString("world.tournament-world", "TournamentWorld");
        World world = Bukkit.getWorld(worldName);
        if (world != null) {
            String path = "world.lobby";
            event.setRespawnLocation(new Location(world,
                    plugin.getConfig().getDouble(path + ".x", 0.5),
                    plugin.getConfig().getDouble(path + ".y", 82),
                    plugin.getConfig().getDouble(path + ".z", 0.5)));
        }
        manager.handleRespawn(event.getPlayer());
    }

    private boolean isTournamentWorld(World world) {
        World tournamentWorld = Bukkit.getWorld(plugin.getConfig().getString("world.tournament-world", "TournamentWorld"));
        return tournamentWorld != null && tournamentWorld.getUID().equals(world.getUID());
    }
}
