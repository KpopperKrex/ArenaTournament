package com.arenatournament.player;

import org.bukkit.GameMode;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Durable backup of a participant's pre-tournament player state. */
public final class PlayerSnapshot {
    private final File file;
    private PlayerSnapshot(File file) { this.file = file; }

    public static PlayerSnapshot captureAndSave(JavaPlugin plugin, Player player) throws IOException {
        File folder = new File(plugin.getDataFolder(), "player-backups");
        if (!folder.exists() && !folder.mkdirs()) throw new IOException("Could not create player-backups directory");
        File file = new File(folder, player.getUniqueId() + ".yml");
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("inventory.contents", player.getInventory().getStorageContents());
        yaml.set("inventory.armor", player.getInventory().getArmorContents());
        yaml.set("inventory.offhand", player.getInventory().getItemInOffHand());
        yaml.set("level", player.getLevel());
        yaml.set("exp", player.getExp());
        yaml.set("total-exp", player.getTotalExperience());
        yaml.set("health", player.getHealth());
        yaml.set("food", player.getFoodLevel());
        yaml.set("saturation", player.getSaturation());
        yaml.set("exhaustion", player.getExhaustion());
        yaml.set("game-mode", player.getGameMode().name());
        yaml.set("allow-flight", player.getAllowFlight());
        yaml.set("flying", player.isFlying());
        yaml.set("fire-ticks", player.getFireTicks());
        List<PotionEffect> effects = new ArrayList<>(player.getActivePotionEffects());
        yaml.set("effects", effects);
        yaml.save(file);
        return new PlayerSnapshot(file);
    }

    public static PlayerSnapshot existing(JavaPlugin plugin, UUID playerId) {
        File file = new File(new File(plugin.getDataFolder(), "player-backups"), playerId + ".yml");
        return file.isFile() ? new PlayerSnapshot(file) : null;
    }

    public void restore(Player player) throws IOException {
        if (!file.isFile()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        player.closeInventory();
        player.getInventory().clear();
        player.getInventory().setStorageContents(itemArray(yaml.getList("inventory.contents", List.of())));
        player.getInventory().setArmorContents(itemArray(yaml.getList("inventory.armor", List.of())));
        player.getInventory().setItemInOffHand(yaml.getItemStack("inventory.offhand"));
        player.setLevel(yaml.getInt("level"));
        player.setExp((float) yaml.getDouble("exp"));
        player.setTotalExperience(yaml.getInt("total-exp"));
        player.setFoodLevel(yaml.getInt("food", 20));
        player.setSaturation((float) yaml.getDouble("saturation", 5));
        player.setExhaustion((float) yaml.getDouble("exhaustion", 0));
        player.setGameMode(GameMode.valueOf(yaml.getString("game-mode", "SURVIVAL")));
        player.setAllowFlight(yaml.getBoolean("allow-flight"));
        if (player.getAllowFlight()) player.setFlying(yaml.getBoolean("flying"));
        player.setFireTicks(yaml.getInt("fire-ticks"));
        double health = yaml.getDouble("health", 20);
        double maxHealth = player.getAttribute(Attribute.MAX_HEALTH) == null ? 20 : player.getAttribute(Attribute.MAX_HEALTH).getValue();
        player.setHealth(Math.max(1, Math.min(health, maxHealth)));
        for (PotionEffect effect : player.getActivePotionEffects()) player.removePotionEffect(effect.getType());
        for (Object value : yaml.getList("effects", List.of())) if (value instanceof PotionEffect effect) player.addPotionEffect(effect);
        player.updateInventory();
        delete();
    }

    private ItemStack[] itemArray(List<?> values) {
        ItemStack[] items = new ItemStack[values.size()];
        for (int i = 0; i < values.size(); i++) items[i] = values.get(i) instanceof ItemStack item ? item : null;
        return items;
    }

    public void delete() {
        if (file.exists() && !file.delete()) file.deleteOnExit();
    }
}
