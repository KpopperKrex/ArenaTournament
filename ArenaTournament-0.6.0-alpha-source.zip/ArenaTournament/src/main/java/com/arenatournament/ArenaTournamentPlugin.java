package com.arenatournament;

import com.arenatournament.arena.TournamentWorldBuilder;
import com.arenatournament.command.TournamentCommand;
import com.arenatournament.listener.MatchListener;
import com.arenatournament.tournament.TournamentManager;
import com.arenatournament.view.TournamentViewManager;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class ArenaTournamentPlugin extends JavaPlugin {
    private TournamentManager tournamentManager;
    private TournamentWorldBuilder worldBuilder;
    private TournamentViewManager viewManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.tournamentManager = new TournamentManager(this);
        this.worldBuilder = new TournamentWorldBuilder(this);
        this.viewManager = new TournamentViewManager(this, tournamentManager);

        PluginCommand command = getCommand("at");
        if (command == null) {
            getLogger().severe("Command 'at' is missing from plugin.yml. Disabling plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        TournamentCommand executor = new TournamentCommand(this, tournamentManager);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
        getServer().getPluginManager().registerEvents(new MatchListener(this, tournamentManager), this);
        getServer().getPluginManager().registerEvents(viewManager, this);

        if (getConfig().getBoolean("world.auto-create-world", true)) {
            worldBuilder.initialize();
        }
        getLogger().info("ArenaTournament alpha enabled. Use /at validate to inspect the generated world and arena setup.");
    }

    @Override
    public void onDisable() {
        if (viewManager != null) viewManager.shutdown();
        if (tournamentManager != null) tournamentManager.shutdown();
    }

    public TournamentManager getTournamentManager() { return tournamentManager; }
    public TournamentWorldBuilder getWorldBuilder() { return worldBuilder; }
    public TournamentViewManager getViewManager() { return viewManager; }
}
