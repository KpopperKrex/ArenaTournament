package com.arenatournament.view;

import com.arenatournament.ArenaTournamentPlugin;
import com.arenatournament.arena.ArenaDefinition;
import com.arenatournament.model.MatchStatus;
import com.arenatournament.model.TournamentMatch;
import com.arenatournament.tournament.TournamentManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.ScoreboardManager;

import java.util.*;

/** Spectator controls, clickable match/bracket menus, and a per-player live sidebar. */
public final class TournamentViewManager implements Listener {
    private final ArenaTournamentPlugin plugin;
    private final TournamentManager tournament;
    private final Set<UUID> spectators = new HashSet<>();
    private final Map<UUID, ReturnState> returnStates = new HashMap<>();
    private final Map<UUID, UUID> watchedMatches = new HashMap<>();
    private final Map<UUID, Scoreboard> previousBoards = new HashMap<>();
    private BukkitTask sidebarTask;

    public TournamentViewManager(ArenaTournamentPlugin plugin, TournamentManager tournament) {
        this.plugin = plugin;
        this.tournament = tournament;
        long interval = Math.max(10, plugin.getConfig().getLong("scoreboard.update-interval-ticks", 20));
        if (plugin.getConfig().getBoolean("scoreboard.enabled", true)) {
            sidebarTask = Bukkit.getScheduler().runTaskTimer(plugin, this::updateSidebars, 1L, interval);
        }
    }

    public boolean isSpectator(UUID id) { return spectators.contains(id); }

    public boolean startSpectating(Player player) {
        if (!plugin.getConfig().getBoolean("spectators.enabled", true)) return false;
        UUID id = player.getUniqueId();
        if (tournament.isActiveMatchPlayer(id)) {
            player.sendMessage(color("&cYou cannot enter spectator mode while your match is active."));
            return false;
        }
        if (!spectators.contains(id)) {
            returnStates.put(id, new ReturnState(player.getLocation().clone(), player.getGameMode(), player.getAllowFlight()));
            spectators.add(id);
        }
        player.closeInventory();
        player.setGameMode(GameMode.SPECTATOR);
        player.setAllowFlight(true);
        Location hub = configuredLocation("world.spectator-hub");
        if (hub != null) player.teleport(hub);
        player.sendMessage(color("&aYou are now spectating. Use /at watch to choose a match or /at unspectate to leave."));
        return true;
    }

    public void stopSpectating(Player player) {
        UUID id = player.getUniqueId();
        if (!spectators.remove(id)) return;
        ReturnState state = returnStates.remove(id);
        watchedMatches.remove(id);
        player.closeInventory();
        if (state != null) {
            player.setGameMode(state.gameMode());
            player.setAllowFlight(state.allowFlight());
            if (state.location().getWorld() != null) player.teleport(state.location());
        } else {
            Location lobby = configuredLocation("world.lobby");
            if (lobby != null) player.teleport(lobby);
            player.setGameMode(GameMode.SURVIVAL);
        }
        player.sendMessage(color("&eSpectator mode ended."));
    }

    public void openWatchMenu(Player player) {
        if (!plugin.getConfig().getBoolean("spectators.enabled", true)) {
            player.sendMessage(color("&cSpectating is disabled."));
            return;
        }
        if (!spectators.contains(player.getUniqueId()) && !startSpectating(player)) return;
        MatchMenuHolder holder = new MatchMenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&8Live tournament matches"));
        holder.setInventory(inventory);
        List<TournamentMatch> active = tournament.getActiveMatches();
        int slot = 0;
        for (TournamentMatch match : active) {
            if (slot >= 45) break;
            ArenaDefinition arena = plugin.getWorldBuilder().getArenas().stream()
                    .filter(a -> a.id().equals(match.getArenaId())).findFirst().orElse(null);
            ItemStack item = new ItemStack(match.getStatus() == MatchStatus.RUNNING ? Material.DIAMOND_SWORD : Material.CLOCK);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(color("&e" + tournament.getDisplayName(match.getPlayerOne()) + " &7vs &e" + tournament.getDisplayName(match.getPlayerTwo())));
                meta.setLore(List.of(color("&7Round " + match.getRound() + " • " + match.getStatus()),
                        color("&7Arena: " + (arena == null ? match.getArenaId() : arena.displayName())),
                        color(match.getStatus() == MatchStatus.RUNNING ? "&7Time left: " + tournament.getRemainingSeconds(match.getId()) + "s" : "&7Starting soon"),
                        color("&aClick to watch this match")));
                item.setItemMeta(meta);
            }
            inventory.setItem(slot, item);
            holder.matchSlots.put(slot, match.getId());
            slot++;
        }
        if (active.isEmpty()) {
            inventory.setItem(22, named(Material.BARRIER, "&cNo active matches", "&7There are no matches to watch right now."));
        }
        inventory.setItem(49, named(Material.COMPASS, "&eReturn to spectator hub", "&7Click to go back to the hub."));
        player.openInventory(inventory);
    }

    public void openBracketMenu(Player player) {
        BracketMenuHolder holder = new BracketMenuHolder();
        Inventory inventory = Bukkit.createInventory(holder, 54, color("&8Tournament bracket"));
        holder.setInventory(inventory);
        int slot = 0;
        for (int round = 1; round <= Math.max(1, tournament.getCurrentRound()); round++) {
            if (slot >= 45) break;
            inventory.setItem(slot++, named(Material.PAPER, "&6Round " + round, "&7Tournament progression"));
            for (TournamentMatch match : tournament.getMatches()) {
                if (match.getRound() != round || slot >= 45) continue;
                Material material = match.getStatus() == MatchStatus.FINISHED ? Material.LIME_DYE
                        : match.getStatus() == MatchStatus.RUNNING ? Material.DIAMOND_SWORD
                        : match.getStatus() == MatchStatus.COUNTDOWN ? Material.CLOCK : Material.GRAY_DYE;
                String result = match.getWinner() == null ? "&7Result: pending" : "&aWinner: " + tournament.getDisplayName(match.getWinner());
                inventory.setItem(slot++, named(material,
                        "&f" + tournament.getDisplayName(match.getPlayerOne()) + " &7vs &f" + tournament.getDisplayName(match.getPlayerTwo()),
                        "&7Status: " + match.getStatus(), result,
                        "&7Arena: " + (match.getArenaId() == null ? "Unassigned" : match.getArenaId()),
                        match.getStatus() == MatchStatus.RUNNING ? "&7Time left: " + tournament.getRemainingSeconds(match.getId()) + "s" : "&7Time: not started"));
            }
        }
        if (tournament.getChampion() != null) inventory.setItem(49, named(Material.NETHER_STAR, "&6Champion: " + tournament.getDisplayName(tournament.getChampion())));
        else inventory.setItem(49, named(Material.BOOK, "&e" + tournament.getStatus(), "&7Round: " + tournament.getCurrentRound()));
        player.openInventory(inventory);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMenuClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getView().getTopInventory().getHolder();
        if (!(holder instanceof MatchMenuHolder) && !(holder instanceof BracketMenuHolder)) return;
        event.setCancelled(true);
        if (holder instanceof MatchMenuHolder matchHolder) {
            UUID matchId = matchHolder.matchSlots.get(event.getRawSlot());
            if (matchId != null && spectators.contains(player.getUniqueId())) watchMatch(player, matchId);
            else if (event.getRawSlot() == 49) {
                Location hub = configuredLocation("world.spectator-hub");
                if (hub != null) player.teleport(hub);
                player.closeInventory();
            }
        }
    }

    private void watchMatch(Player player, UUID matchId) {
        TournamentMatch match = tournament.getMatch(matchId);
        if (match == null || (match.getStatus() != MatchStatus.RUNNING && match.getStatus() != MatchStatus.COUNTDOWN)) {
            player.sendMessage(color("&cThat match is no longer active."));
            openWatchMenu(player);
            return;
        }
        ArenaDefinition arena = plugin.getWorldBuilder().getArenas().stream()
                .filter(a -> a.id().equals(match.getArenaId())).findFirst().orElse(null);
        if (arena == null) {
            player.sendMessage(color("&cThe match arena could not be found."));
            return;
        }
        UUID previousMatch = watchedMatches.get(player.getUniqueId());
        if (previousMatch != null && !previousMatch.equals(matchId)
                && !plugin.getConfig().getBoolean("spectators.can-switch-arenas", true)) {
            player.sendMessage(color("&cSwitching between arenas is disabled."));
            return;
        }
        if (!spectators.contains(player.getUniqueId()) && !startSpectating(player)) return;
        watchedMatches.put(player.getUniqueId(), matchId);
        player.setGameMode(GameMode.SPECTATOR);
        player.teleport(arena.spectatorSpawn());
        player.closeInventory();
        player.sendMessage(color("&aWatching &f" + tournament.getDisplayName(match.getPlayerOne()) + " &7vs &f" + tournament.getDisplayName(match.getPlayerTwo()) + "&a."));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player player && spectators.contains(player.getUniqueId())) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorInventory(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player && spectators.contains(player.getUniqueId())
                && !(event.getView().getTopInventory().getHolder() instanceof MatchMenuHolder)
                && !(event.getView().getTopInventory().getHolder() instanceof BracketMenuHolder)) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorDrag(InventoryDragEvent event) {
        if (event.getWhoClicked() instanceof Player player && spectators.contains(player.getUniqueId())) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorDrop(PlayerDropItemEvent event) {
        if (spectators.contains(event.getPlayer().getUniqueId())) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player && spectators.contains(player.getUniqueId())) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpectatorInteract(PlayerInteractEvent event) {
        if (spectators.contains(event.getPlayer().getUniqueId()) && !plugin.getConfig().getBoolean("spectators.can-interact", false)) event.setCancelled(true);
    }
    @EventHandler public void onSpectatorQuit(PlayerQuitEvent event) {
        // Keep the return state until reconnect so a temporary disconnect does not strand the player in spectator mode.
    }
    @EventHandler public void onSpectatorJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (spectators.contains(player.getUniqueId())) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                player.setGameMode(GameMode.SPECTATOR);
                Location hub = configuredLocation("world.spectator-hub");
                if (hub != null) player.teleport(hub);
            });
        }
    }

    private void updateSidebars() {
        if (!plugin.getConfig().getBoolean("scoreboard.enabled", true)) return;
        ScoreboardManager manager = Bukkit.getScoreboardManager();
        if (manager == null) return;
        for (Player player : Bukkit.getOnlinePlayers()) {
            Scoreboard board = player.getScoreboard();
            if (!previousBoards.containsKey(player.getUniqueId())) previousBoards.put(player.getUniqueId(), board);
            Scoreboard fresh = manager.getNewScoreboard();
            Objective objective = fresh.registerNewObjective("attourney", "dummy", color("&6&l" + shortText(plugin.getConfig().getString("branding.tournament-name", "TOURNAMENT"), 28)));
            objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            List<String> lines = new ArrayList<>();
            lines.add("&7" + plugin.getConfig().getString("branding.server-name", "YOUR SERVER"));
            lines.add("&fStatus: &e" + tournament.getStatus());
            lines.add("&fRound: &e" + (tournament.getCurrentRound() == 0 ? "-" : tournament.getCurrentRound()));
            lines.add("&fPlayers: &e" + tournament.getParticipantCount() + "/24");
            lines.add("&fLive matches: &e" + tournament.getActiveMatches().size());
            int shown = 0;
            for (TournamentMatch match : tournament.getActiveMatches()) {
                if (shown++ >= 3) break;
                lines.add("&b" + shortText(tournament.getDisplayName(match.getPlayerOne()), 10) + " &7vs &b" + shortText(tournament.getDisplayName(match.getPlayerTwo()), 10));
                if (match.getStatus() == MatchStatus.RUNNING && shown == 1) lines.add("&7Time left: &e" + tournament.getRemainingSeconds(match.getId()) + "s");
            }
            if (tournament.getChampion() != null) lines.add("&6Winner: " + shortText(tournament.getDisplayName(tournament.getChampion()), 16));
            lines.add("&ewww: " + shortText(plugin.getConfig().getString("branding.website", ""), 20));
            ChatColor[] unique = ChatColor.values();
            int score = lines.size();
            for (int i = 0; i < lines.size() && i < 15; i++) {
                String entry = unique[i].toString();
                objective.getScore(entry).setScore(score--);
                // Use a team prefix for readable line text while keeping each entry unique.
                var team = fresh.registerNewTeam("line" + i);
                team.addEntry(entry);
                team.setPrefix(color(shortText(lines.get(i), 64)));
            }
            player.setScoreboard(fresh);
        }
    }

    public void shutdown() {
        if (sidebarTask != null) sidebarTask.cancel();
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (spectators.contains(player.getUniqueId())) stopSpectating(player);
            Scoreboard old = previousBoards.get(player.getUniqueId());
            if (old != null) player.setScoreboard(old);
        }
        previousBoards.clear();
    }

    private Location configuredLocation(String path) {
        String worldName = plugin.getConfig().getString(path + ".world", plugin.getConfig().getString("world.tournament-world", "TournamentWorld"));
        org.bukkit.World world = Bukkit.getWorld(worldName);
        if (world == null) return null;
        return new Location(world, plugin.getConfig().getDouble(path + ".x"), plugin.getConfig().getDouble(path + ".y"), plugin.getConfig().getDouble(path + ".z"));
    }

    private ItemStack named(Material material, String title, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(title));
            meta.setLore(Arrays.stream(lore).map(this::color).toList());
            item.setItemMeta(meta);
        }
        return item;
    }
    private String color(String text) { return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text); }
    private String shortText(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, Math.max(0, max - 1)) + "…";
    }

    private record ReturnState(Location location, GameMode gameMode, boolean allowFlight) { }
    private static final class MatchMenuHolder implements InventoryHolder {
        private final Map<Integer, UUID> matchSlots = new HashMap<>();
        private Inventory inventory;
        void setInventory(Inventory inventory) { this.inventory = inventory; }
        @Override public Inventory getInventory() { return inventory; }
    }
    private static final class BracketMenuHolder implements InventoryHolder {
        private Inventory inventory;
        void setInventory(Inventory inventory) { this.inventory = inventory; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
