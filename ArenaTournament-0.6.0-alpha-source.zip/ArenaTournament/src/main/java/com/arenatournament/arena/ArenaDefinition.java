package com.arenatournament.arena;

import org.bukkit.Location;
import org.bukkit.World;

/** Immutable locations and cuboid bounds for one generated tournament arena. */
public record ArenaDefinition(
        String id,
        String displayName,
        World world,
        int minX,
        int maxX,
        int minY,
        int maxY,
        int minZ,
        int maxZ,
        Location playerOneSpawn,
        Location playerTwoSpawn,
        Location spectatorSpawn
) {
    public boolean contains(Location location) {
        if (location == null || location.getWorld() == null || !world.getUID().equals(location.getWorld().getUID())) {
            return false;
        }
        return location.getBlockX() >= minX && location.getBlockX() <= maxX
                && location.getBlockY() >= minY && location.getBlockY() <= maxY
                && location.getBlockZ() >= minZ && location.getBlockZ() <= maxZ;
    }
}
