package com.arenatournament.arena;

import com.arenatournament.ArenaTournamentPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.WorldBorder;

import java.util.ArrayList;
import java.util.List;

/** Creates a deterministic tournament map using the Paper world API. */
public final class TournamentWorldBuilder {
    private static final int FLOOR_Y = 80;
    private static final int ARENA_HALF = 25;
    private static final int WALL_HEIGHT = 5;
    private final ArenaTournamentPlugin plugin;
    private final List<ArenaDefinition> arenas = new ArrayList<>();

    private static final ArenaTheme[] THEMES = {
            new ArenaTheme("Medieval Colosseum", Material.STONE_BRICKS, Material.CRACKED_STONE_BRICKS, Material.POLISHED_ANDESITE, Material.MOSSY_STONE_BRICKS, Material.STONE_BRICK_WALL),
            new ArenaTheme("Nether Fortress", Material.POLISHED_BLACKSTONE_BRICKS, Material.BLACKSTONE, Material.NETHER_BRICKS, Material.CRACKED_POLISHED_BLACKSTONE_BRICKS, Material.POLISHED_BLACKSTONE_WALL),
            new ArenaTheme("Frozen Kingdom", Material.PACKED_ICE, Material.BLUE_ICE, Material.SNOW_BLOCK, Material.ICE, Material.ICE),
            new ArenaTheme("Japanese Temple", Material.MANGROVE_PLANKS, Material.RED_NETHER_BRICKS, Material.POLISHED_DEEPSLATE, Material.MUD_BRICKS, Material.DEEPSLATE_BRICK_WALL),
            new ArenaTheme("Desert Ruins", Material.SANDSTONE, Material.CUT_SANDSTONE, Material.SMOOTH_SANDSTONE, Material.CHISELED_SANDSTONE, Material.SANDSTONE_WALL),
            new ArenaTheme("Ancient Jungle", Material.MOSS_BLOCK, Material.MOSSY_STONE_BRICKS, Material.JUNGLE_PLANKS, Material.ROOTED_DIRT, Material.MOSSY_COBBLESTONE_WALL),
            new ArenaTheme("End Dimension", Material.END_STONE_BRICKS, Material.PURPUR_BLOCK, Material.OBSIDIAN, Material.END_STONE, Material.END_STONE_BRICK_WALL),
            new ArenaTheme("Royal Castle", Material.QUARTZ_BRICKS, Material.POLISHED_BLACKSTONE, Material.GOLD_BLOCK, Material.CHISELED_QUARTZ_BLOCK, Material.POLISHED_BLACKSTONE_BRICK_WALL)
    };

    public TournamentWorldBuilder(ArenaTournamentPlugin plugin) {
        this.plugin = plugin;
    }

    /** Loads or creates the world and builds it once. Must be called on the server thread. */
    public boolean initialize() {
        String worldName = plugin.getConfig().getString("world.tournament-world", "TournamentWorld");
        World world = Bukkit.getWorld(worldName);
        boolean freshWorld = false;
        if (world == null && plugin.getConfig().getBoolean("world.auto-create-world", true)) {
            java.nio.file.Path worldFolder = Bukkit.getWorldContainer().toPath().resolve(worldName);
            freshWorld = !java.nio.file.Files.exists(worldFolder);
            WorldCreator creator = new WorldCreator(worldName);
            creator.type(WorldType.FLAT);
            creator.generateStructures(false);
            world = Bukkit.createWorld(creator);
        }
        if (world == null) {
            plugin.getLogger().warning("Tournament world '" + worldName + "' is not loaded. Use /at setup or enable world.auto-create-world.");
            return false;
        }

        world.setAutoSave(true);
        world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        world.setGameRule(GameRule.DO_MOB_SPAWNING, false);
        world.setGameRule(GameRule.KEEP_INVENTORY, true);
        world.setTime(6000L);
        WorldBorder border = world.getWorldBorder();
        border.setCenter(0, 0);
        border.setSize(1200);

        boolean mayBuild = freshWorld || plugin.getConfig().getBoolean("world.allow-build-existing-world", false);
        if (plugin.getConfig().getBoolean("world.generate-builds", true)
                && !plugin.getConfig().getBoolean("world.generated", false) && mayBuild) {
            buildWorld(world);
            plugin.getConfig().set("world.generated", true);
            plugin.saveConfig();
            plugin.getLogger().info("Generated TournamentWorld structures. They will not be overwritten on subsequent starts.");
        } else if (!plugin.getConfig().getBoolean("world.generated", false)) {
            plugin.getLogger().warning("TournamentWorld already exists but is not marked generated. It was left untouched. Set world.allow-build-existing-world: true only if you intend the plugin to build over this dedicated world.");
            return false;
        }
        registerArenaLocations(world);
        return true;
    }

    /** Explicit admin repair/setup entry point. It never overwrites an already generated map. */
    public boolean setupIfNeeded() {
        String worldName = plugin.getConfig().getString("world.tournament-world", "TournamentWorld");
        World world = Bukkit.getWorld(worldName);
        boolean freshWorld = false;
        if (world == null) {
            java.nio.file.Path worldFolder = Bukkit.getWorldContainer().toPath().resolve(worldName);
            freshWorld = !java.nio.file.Files.exists(worldFolder);
            world = Bukkit.createWorld(new WorldCreator(worldName).type(WorldType.FLAT).generateStructures(false));
        }
        if (world == null) return false;
        if (!plugin.getConfig().getBoolean("world.generated", false)) {
            if (!freshWorld && !plugin.getConfig().getBoolean("world.allow-build-existing-world", false)) {
                plugin.getLogger().warning("Refusing to build over an existing TournamentWorld. Set world.allow-build-existing-world: true only for a dedicated empty world.");
                return false;
            }
            buildWorld(world);
            plugin.getConfig().set("world.generated", true);
            plugin.saveConfig();
        }
        registerArenaLocations(world);
        return true;
    }

    private void buildWorld(World world) {
        // 4 columns x 2 rows; the central lobby and northern grand-final stadium remain separate.
        int[] xs = {-300, -100, 100, 300};
        int[] zs = {-150, 150};
        int index = 0;
        for (int z : zs) {
            for (int x : xs) {
                buildArena(world, "arena" + (index + 1), THEMES[index], x, z);
                index++;
            }
        }
        buildLobby(world, 0, 0);
        buildSpectatorHub(world, 110, 0);
        buildGrandFinal(world, 0, 440);
        buildPath(world, 0, 0, 0, 440);
        world.setSpawnLocation(0, FLOOR_Y + 2, 0);
        world.getChunkAt(0, 0).load(true);
        world.getChunkAt(0, 27).load(true);
    }

    private void buildArena(World world, String id, ArenaTheme theme, int cx, int cz) {
        int minX = cx - ARENA_HALF, maxX = cx + ARENA_HALF;
        int minZ = cz - ARENA_HALF, maxZ = cz + ARENA_HALF;
        fill(world, minX, FLOOR_Y - 1, minZ, maxX, FLOOR_Y - 1, maxZ, Material.BEDROCK);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                Material floor = ((x + z) & 7) == 0 ? theme.accent : theme.floor;
                world.getBlockAt(x, FLOOR_Y, z).setType(floor, false);
            }
        }
        // Raised central duel pad and mirrored spawn pads.
        fill(world, cx - 5, FLOOR_Y, cz - 5, cx + 5, FLOOR_Y + 1, cz + 5, theme.accent);
        buildSpawnPad(world, cx - 15, FLOOR_Y, cz, theme.trim);
        buildSpawnPad(world, cx + 15, FLOOR_Y, cz, theme.trim);
        // Low perimeter wall, with open center gates on the two ends.
        for (int y = FLOOR_Y + 1; y <= FLOOR_Y + WALL_HEIGHT; y++) {
            for (int p = minX; p <= maxX; p++) {
                if (!(Math.abs(p - cx) <= 3)) {
                    world.getBlockAt(p, y, minZ).setType(theme.wall, false);
                    world.getBlockAt(p, y, maxZ).setType(theme.wall, false);
                }
                world.getBlockAt(minX, y, p - cx + cz).setType(theme.wall, false);
                world.getBlockAt(maxX, y, p - cx + cz).setType(theme.wall, false);
            }
        }
        // Four corner towers, decorative and outside the combat floor.
        for (int dx : new int[]{-1, 1}) for (int dz : new int[]{-1, 1}) {
            int tx = cx + dx * 23, tz = cz + dz * 23;
            fill(world, tx - 2, FLOOR_Y + 1, tz - 2, tx + 2, FLOOR_Y + 7, tz + 2, theme.trim);
            fill(world, tx - 1, FLOOR_Y + 7, tz - 1, tx + 1, FLOOR_Y + 7, tz + 1, theme.accent);
        }
        // Raised spectator deck above the arena, with a clear teleport landing point.
        fill(world, cx - 6, FLOOR_Y + 12, cz - 6, cx + 6, FLOOR_Y + 12, cz + 6, Material.TINTED_GLASS);
        fill(world, cx - 2, FLOOR_Y + 1, cz - 2, cx + 2, FLOOR_Y + 11, cz + 2, theme.trim);
        fill(world, cx - 1, FLOOR_Y + 13, cz - 1, cx + 1, FLOOR_Y + 16, cz + 1, Material.AIR);
        // Spawn markers are deliberately visible in the supplied default map.
        world.getBlockAt(cx - 15, FLOOR_Y + 1, cz).setType(Material.LIGHT, false);
        world.getBlockAt(cx + 15, FLOOR_Y + 1, cz).setType(Material.LIGHT, false);
    }

    private void buildSpawnPad(World world, int x, int y, int z, Material material) {
        fill(world, x - 3, y, z - 3, x + 3, y, z + 3, material);
        fill(world, x - 2, y + 1, z - 2, x + 2, y + 1, z + 2, Material.AIR);
    }

    private void buildLobby(World world, int cx, int cz) {
        fill(world, cx - 32, FLOOR_Y - 1, cz - 32, cx + 32, FLOOR_Y - 1, cz + 32, Material.BEDROCK);
        fill(world, cx - 30, FLOOR_Y, cz - 30, cx + 30, FLOOR_Y, cz + 30, Material.POLISHED_ANDESITE);
        fill(world, cx - 12, FLOOR_Y + 1, cz - 12, cx + 12, FLOOR_Y + 1, cz + 12, Material.BLACKSTONE);
        fill(world, cx - 10, FLOOR_Y + 2, cz - 10, cx + 10, FLOOR_Y + 2, cz + 10, Material.GOLD_BLOCK);
        fill(world, cx - 8, FLOOR_Y + 3, cz - 8, cx + 8, FLOOR_Y + 3, cz + 8, Material.POLISHED_BLACKSTONE);
        for (int dx : new int[]{-1, 1}) for (int dz : new int[]{-1, 1}) {
            fill(world, cx + dx * 25 - 2, FLOOR_Y + 1, cz + dz * 25 - 2,
                    cx + dx * 25 + 2, FLOOR_Y + 9, cz + dz * 25 + 2, Material.QUARTZ_BRICKS);
        }
        // Spawn platform and clear landing volume.
        fill(world, cx - 4, FLOOR_Y + 1, cz - 4, cx + 4, FLOOR_Y + 1, cz + 4, Material.GOLD_BLOCK);
        fill(world, cx - 3, FLOOR_Y + 2, cz - 3, cx + 3, FLOOR_Y + 5, cz + 3, Material.AIR);
        plugin.getConfig().set("world.lobby", locationMap(cx + 0.5, FLOOR_Y + 2, cz + 0.5));
    }

    private void buildSpectatorHub(World world, int cx, int cz) {
        fill(world, cx - 24, FLOOR_Y - 1, cz - 24, cx + 24, FLOOR_Y - 1, cz + 24, Material.BEDROCK);
        fill(world, cx - 22, FLOOR_Y, cz - 22, cx + 22, FLOOR_Y, cz + 22, Material.DEEPSLATE_TILES);
        fill(world, cx - 15, FLOOR_Y + 1, cz - 15, cx + 15, FLOOR_Y + 1, cz + 15, Material.TINTED_GLASS);
        fill(world, cx - 10, FLOOR_Y + 2, cz - 10, cx + 10, FLOOR_Y + 2, cz + 10, Material.POLISHED_BLACKSTONE);
        for (int dx : new int[]{-1, 1}) for (int dz : new int[]{-1, 1}) {
            int tx = cx + dx * 18, tz = cz + dz * 18;
            fill(world, tx - 2, FLOOR_Y + 1, tz - 2, tx + 2, FLOOR_Y + 8, tz + 2, Material.CRYING_OBSIDIAN);
            fill(world, tx - 3, FLOOR_Y + 8, tz - 3, tx + 3, FLOOR_Y + 8, tz + 3, Material.GLOWSTONE);
        }
        fill(world, cx - 4, FLOOR_Y + 2, cz - 4, cx + 4, FLOOR_Y + 2, cz + 4, Material.SEA_LANTERN);
        fill(world, cx - 3, FLOOR_Y + 3, cz - 3, cx + 3, FLOOR_Y + 6, cz + 3, Material.AIR);
        plugin.getConfig().set("world.spectator-hub", locationMap(cx + 0.5, FLOOR_Y + 3, cz + 0.5));
    }

    private void buildGrandFinal(World world, int cx, int cz) {
        int half = 42;
        fill(world, cx - half, FLOOR_Y - 1, cz - half, cx + half, FLOOR_Y - 1, cz + half, Material.BEDROCK);
        fill(world, cx - half, FLOOR_Y, cz - half, cx + half, FLOOR_Y, cz + half, Material.POLISHED_BLACKSTONE_BRICKS);
        fill(world, cx - 20, FLOOR_Y + 1, cz - 20, cx + 20, FLOOR_Y + 1, cz + 20, Material.QUARTZ_BRICKS);
        fill(world, cx - 5, FLOOR_Y + 1, cz - 5, cx + 5, FLOOR_Y + 1, cz + 5, Material.GOLD_BLOCK);
        for (int y = FLOOR_Y + 1; y <= FLOOR_Y + 12; y++) {
            for (int p = cx - half; p <= cx + half; p++) {
                if (Math.abs(p - cx) > 8) {
                    world.getBlockAt(p, y, cz - half).setType(Material.POLISHED_BLACKSTONE_BRICKS, false);
                    world.getBlockAt(p, y, cz + half).setType(Material.POLISHED_BLACKSTONE_BRICKS, false);
                }
                world.getBlockAt(cx - half, y, p - cx + cz).setType(Material.POLISHED_BLACKSTONE_BRICKS, false);
                world.getBlockAt(cx + half, y, p - cx + cz).setType(Material.POLISHED_BLACKSTONE_BRICKS, false);
            }
        }
        for (int dx : new int[]{-1, 1}) for (int dz : new int[]{-1, 1}) {
            int tx = cx + dx * 35, tz = cz + dz * 35;
            fill(world, tx - 3, FLOOR_Y + 1, tz - 3, tx + 3, FLOOR_Y + 16, tz + 3, Material.QUARTZ_BRICKS);
            fill(world, tx - 4, FLOOR_Y + 16, tz - 4, tx + 4, FLOOR_Y + 16, tz + 4, Material.GOLD_BLOCK);
        }
        // Four stepped spectator stands around the combat floor.
        for (int row = 0; row < 7; row++) {
            int y = FLOOR_Y + 1 + row;
            int inset = 31 - row * 2;
            fill(world, cx - 30, y, cz - inset, cx + 30, y, cz - inset + 1, row % 2 == 0 ? Material.POLISHED_BLACKSTONE : Material.QUARTZ_BRICKS);
            fill(world, cx - 30, y, cz + inset - 1, cx + 30, y, cz + inset, row % 2 == 0 ? Material.POLISHED_BLACKSTONE : Material.QUARTZ_BRICKS);
            fill(world, cx - inset, y, cz - 30, cx - inset + 1, y, cz + 30, row % 2 == 0 ? Material.POLISHED_BLACKSTONE : Material.QUARTZ_BRICKS);
            fill(world, cx + inset - 1, y, cz - 30, cx + inset, y, cz + 30, row % 2 == 0 ? Material.POLISHED_BLACKSTONE : Material.QUARTZ_BRICKS);
        }
        plugin.getConfig().set("world.grand-final.player-one", locationMap(cx - 12.5, FLOOR_Y + 2, cz + 0.5));
        plugin.getConfig().set("world.grand-final.player-two", locationMap(cx + 12.5, FLOOR_Y + 2, cz + 0.5));
        plugin.getConfig().set("world.grand-final.spectator", locationMap(cx + 0.5, FLOOR_Y + 19, cz - 0.5));
    }

    private void buildPath(World world, int x1, int z1, int x2, int z2) {
        for (int z = z1 + 33; z < z2 - 42; z++) {
            for (int x = -3; x <= 3; x++) world.getBlockAt(x, FLOOR_Y, z).setType(Material.SMOOTH_STONE, false);
        }
    }

    private void registerArenaLocations(World world) {
        arenas.clear();
        int[] xs = {-300, -100, 100, 300};
        int[] zs = {-150, 150};
        int index = 0;
        for (int z : zs) for (int x : xs) {
            String id = "arena" + (++index);
            int cx = x, cz = z;
            ArenaDefinition arena = new ArenaDefinition(
                    id, THEMES[index - 1].name, world,
                    cx - ARENA_HALF, cx + ARENA_HALF, FLOOR_Y, FLOOR_Y + WALL_HEIGHT + 2,
                    cz - ARENA_HALF, cz + ARENA_HALF,
                    new Location(world, cx - 14.5, FLOOR_Y + 1, cz + 0.5, -90, 0),
                    new Location(world, cx + 15.5, FLOOR_Y + 1, cz + 0.5, 90, 0),
                    new Location(world, cx + 0.5, FLOOR_Y + 15, cz + 0.5, 180, 25));
            arenas.add(arena);
            String path = "arenas." + id;
            plugin.getConfig().set(path + ".display-name", arena.displayName());
            plugin.getConfig().set(path + ".center-x", cx);
            plugin.getConfig().set(path + ".center-z", cz);
            plugin.getConfig().set(path + ".min-x", arena.minX());
            plugin.getConfig().set(path + ".max-x", arena.maxX());
            plugin.getConfig().set(path + ".min-y", arena.minY());
            plugin.getConfig().set(path + ".max-y", arena.maxY());
            plugin.getConfig().set(path + ".min-z", arena.minZ());
            plugin.getConfig().set(path + ".max-z", arena.maxZ());
            plugin.getConfig().set(path + ".player-one", locationMap(arena.playerOneSpawn()));
            plugin.getConfig().set(path + ".player-two", locationMap(arena.playerTwoSpawn()));
            plugin.getConfig().set(path + ".spectator", locationMap(arena.spectatorSpawn()));
            plugin.getConfig().set(path + ".enabled", true);
        }
        plugin.getConfig().set("world.spawn", locationMap(0.5, FLOOR_Y + 2, 0.5));
        plugin.saveConfig();
    }

    private java.util.Map<String, Object> locationMap(double x, double y, double z) {
        return java.util.Map.of("world", plugin.getConfig().getString("world.tournament-world", "TournamentWorld"), "x", x, "y", y, "z", z);
    }

    private java.util.Map<String, Object> locationMap(Location location) {
        return locationMap(location.getX(), location.getY(), location.getZ());
    }

    private void fill(World world, int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++)
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++)
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++)
                    world.getBlockAt(x, y, z).setType(material, false);
    }

    public List<ArenaDefinition> getArenas() { return List.copyOf(arenas); }
    public World getWorld() { return Bukkit.getWorld(plugin.getConfig().getString("world.tournament-world", "TournamentWorld")); }

    private record ArenaTheme(String name, Material floor, Material accent, Material trim, Material detail, Material wall) { }
}
