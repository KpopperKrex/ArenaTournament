# TournamentWorld layout (alpha)

The plugin creates a dedicated flat world named `TournamentWorld` by default. It builds structures only once and records the generated flag in `plugins/ArenaTournament/config.yml`.

## Coordinates

All structures are centered around Y=80.

| Area | Center | Approximate footprint |
|---|---:|---:|
| Main lobby | X=0, Z=0 | 65 × 65 blocks |
| Spectator hub | X=110, Z=0 | 49 × 49 blocks |
| Arena 1 — Medieval Colosseum | X=-300, Z=-150 | 51 × 51 blocks |
| Arena 2 — Nether Fortress | X=-100, Z=-150 | 51 × 51 blocks |
| Arena 3 — Frozen Kingdom | X=100, Z=-150 | 51 × 51 blocks |
| Arena 4 — Japanese Temple | X=300, Z=-150 | 51 × 51 blocks |
| Arena 5 — Desert Ruins | X=-300, Z=150 | 51 × 51 blocks |
| Arena 6 — Ancient Jungle | X=-100, Z=150 | 51 × 51 blocks |
| Arena 7 — End Dimension | X=100, Z=150 | 51 × 51 blocks |
| Arena 8 — Royal Castle | X=300, Z=150 | 51 × 51 blocks |
| Grand Final stadium | X=0, Z=440 | 85 × 85 blocks |

The plugin writes the arena boundaries and spawn points to `config.yml` under `arenas.arena1` through `arenas.arena8`. Lobby, spectator hub, and grand-final locations are written under `world.*`.

## Spawn behavior

- Arena fighter spawn points are mirrored on opposite sides of each arena.
- Each arena has an elevated spectator deck location.
- The central lobby is the world spawn.
- The spectator hub is separate from the lobby.
- The grand final has dedicated fighter and spectator locations.

## Safety

The world builder refuses to build over an existing world folder unless `world.allow-build-existing-world: true` is explicitly enabled. Only enable that option for a dedicated empty tournament world after taking a backup. Once generated, the map is not rebuilt on later restarts.

## Current limitations

The alpha map is generated from blocks at runtime. It is not yet a separately bundled world ZIP, schematic, or polished hand-built map. Arena boundaries are recorded, but event-based build/damage protection and arena reset logic are not implemented yet. Inspect the world in-game before using it for an event.
