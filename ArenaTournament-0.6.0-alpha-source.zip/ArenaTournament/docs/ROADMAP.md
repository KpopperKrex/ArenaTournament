# Development roadmap

- [x] Plugin foundation and registration/bracket generation
- [x] Dedicated generated world, eight arenas, lobby, spectator hub, grand-final structure
- [x] Basic match lifecycle and bracket advancement
- [x] Tournament kit and durable per-player inventory/state backups
- [x] Initial arena boundary and player-interference protections
- [ ] Match reset and time-limit/draw handling
- [x] Spectator mode, arena switching, and spectator GUI
- [x] Live sidebar scoreboard and bracket GUI
- [ ] Persistent bracket/match storage and restart recovery
- [ ] Full WorldGuard integration and compatibility tests
- [ ] Paper 1.21.11 compile, integration, and live-server testing


## Stage 5 — spectator and live views (implemented in source, not server-tested)
- [x] Spectator hub teleport and return-state tracking
- [x] Live-match selector GUI with arena spectator locations
- [x] Bracket viewer GUI
- [x] Live sidebar scoreboard
- [x] Spectator interaction restrictions
- [ ] Persist spectator state and active bracket across restarts
- [ ] Integrate sidebar with common scoreboard plugins / configurable scoreboard provider
- [ ] Verify all menus and scoreboard behaviour on Paper 1.21.11


## 0.6.0-alpha
- [x] Match time limit with remaining-health timeout decision
- [x] Pause match clocks during tournament pause or fighter disconnect
- [x] Clear dropped item entities in arenas between matches
- [ ] Full arena schematic snapshot/restore (not needed while block changes remain disabled)
- [ ] Persistent bracket and restart recovery
- [ ] WorldGuard event integration
