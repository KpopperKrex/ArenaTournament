# ArenaTournament — development alpha

Target: Paper 1.21.11, Java 21. This is an evolving source project, not a finished or production-tested plugin.

## Implemented in the current source

- Paper plugin bootstrap, configuration, commands, and 24-player registration.
- 24-player bracket setup: eight byes and eight opening matches.
- Dedicated flat tournament world with eight generated arenas, lobby, spectator hub, and grand-final stadium.
- Basic match lifecycle: arena assignment, countdown, elimination result, disconnect grace period, and round advancement.
- Configurable tournament kit.
- Per-player YAML inventory/state backup created before a match. The backup includes storage inventory, armor, offhand, experience, health, food, potion effects, game mode, flight state, and fire ticks.
- Restores a player's saved state after the match; if they are offline, the backup file remains and is restored when they next join.
- Arena boundary correction for active fighters.
- Prevents active fighters from moving items, dropping or picking up items, and prevents ordinary players from breaking or placing blocks in the dedicated tournament world.
- Restricts player-versus-player damage so fighters can only damage their assigned opponent while their match is running.

## Configuration

Edit `plugins/ArenaTournament/config.yml` after the first server start:

- `branding.*` changes tournament/server branding.
- `kit.items` accepts material names, optionally followed by `:amount`.
- `kit.armor` order is boots, leggings, chestplate, helmet.
- `matches.*` controls simultaneous matches, countdown, and reconnect grace period.
- `world.*` controls the generated dedicated world.
- `spectators.*` controls spectator access, arena switching, and world interaction.
- `scoreboard.*` controls the live sidebar and its refresh interval.

Permission `arenatournament.build` (operator by default) allows building in the dedicated tournament world. Admin commands use `arenatournament.admin`.

## Build and install

Requires JDK 21 and Gradle 8.10+:

```bash
gradle clean build
```

The plugin JAR is created in `build/libs/`. Paper is a compile-only dependency and is not bundled.

## Spectator and viewing commands

- `/at spectate` — enter spectator mode at the spectator hub.
- `/at watch` — open the active-match selector and click a match to watch from its spectator deck.
- `/at unspectate` — return to the location and game mode from before spectating.
- `/at bracket` — open the bracket viewer; from console it prints the bracket as text.

## Important limitations

This alpha has **not** been compiled or tested on a live Paper 1.21.11 server in this environment. Test it on a disposable server and keep backups before trying it on a live server.

Still not implemented: reliable persistent bracket recovery after a crash/restart, match arena reset, time-limit/draw handling, SQLite tournament storage, full WorldGuard event integration, and a complete grand-final-specific flow. The player backup is durable across disconnects, but the bracket/match state itself is currently memory-only.

The generated structures are functional starter builds, not polished custom maps. The plugin should be treated as experimental until the remaining systems are implemented and runtime-tested.


## Stage 5: spectator tools and live tournament views (alpha)

- `/at spectate` enters spectator mode and moves the player to the configured spectator hub.
- `/at watch` opens a clickable list of countdown/running matches; selecting one teleports the spectator to that arena's spectator platform.
- `/at unspectate` restores the spectator's previous location and game mode. Players currently participating in an active match cannot switch themselves into spectator mode.
- `/at bracket` opens an inventory-based bracket view with round, match state, arena and winner details. Console users can still use `/at bracket` to print text.
- A configurable live sidebar shows tournament state, round, registration count, active matches and champion. The plugin restores the player's prior scoreboard when it shuts down.
- Spectators cannot take damage, interact with the world, pick up items, drop items or manipulate inventories.

Limitations: the sidebar currently creates a private scoreboard per player and may conflict visually with other plugins that also manage scoreboards. Spectator sessions are in-memory and are not persisted across a full server restart. The bracket inventory is a viewer, not an administrative bracket editor. WorldGuard integration and live-server testing remain outstanding.


## Version 0.6.0-alpha additions
- Match clocks begin when the countdown finishes and pause while the tournament is paused or either fighter is disconnected.
- At the time limit, the player with the higher remaining health percentage (including absorption) wins. An exact tie pauses the tournament for admin review instead of silently advancing an invalid bracket.
- Dropped item entities inside an arena are cleared before and after a match. Arena blocks are not regenerated because normal player block changes, fire and explosion block damage are already prevented in the tournament world.

This is still an alpha source project. It has not been compiled against Paper or tested on a live server in this environment. Tournament bracket persistence/recovery and actual WorldGuard integration remain unfinished.
